package com.girinuaha.maven.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.girinuaha.maven.dao.EmployeeDao;
import com.girinuaha.maven.model.Employee;

@Transactional
@Service
public class EmployeeService {
	
	@Autowired
	EmployeeDao employeeDao;
	
	public void save(Employee employee) {
		employeeDao.save(employee);
	}

	public List<Employee> getAllEmployee() {
		return employeeDao.getAllEmployee();
	}
	
	/*public List<Employee> getEmployeeById(int id) {
		return employeeDao.getEmployeeById(id);
	}*/
	
	public Employee getEmployeeByID(int id) {
		return employeeDao.getEmployeeById(id);
	}

	public void update(Employee employee) {
		employeeDao.update(employee);
		
	}

	public void delete(int id) {
		employeeDao.delete(id);
	}
}
