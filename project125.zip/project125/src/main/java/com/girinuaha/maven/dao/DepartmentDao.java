package com.girinuaha.maven.dao;

import java.util.List;

import com.girinuaha.maven.model.Department;

public interface DepartmentDao {

	public void save(Department department);

	public List<Department> getAllDepartment();
	
}
