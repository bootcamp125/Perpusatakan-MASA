package com.girinuaha.maven.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

public class MyBean {
	
	private String name;
	@Autowired
	private Address address;
	
	public MyBean() {
		
	}
	
	@PostConstruct
	public void infoName() {
		address.setName("Jalan Bahagia");
		
		System.out.println(this.name);
		System.out.println(this.address.getName());
		
	}
	
	public void setAddress(Address adr) {
		this.address = adr;
		adr.setName("Jalan Bahagia");
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
