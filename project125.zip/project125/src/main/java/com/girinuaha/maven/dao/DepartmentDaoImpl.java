package com.girinuaha.maven.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.girinuaha.maven.model.Department;

@Repository
@SuppressWarnings("unchecked")
public class DepartmentDaoImpl implements DepartmentDao {

	@Autowired
	SessionFactory sessionFactory;
	
	public void save(Department department) {
		Session session = sessionFactory.getCurrentSession();
		session.save(department);
		session.flush();
	}

	public List<Department> getAllDepartment() {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Department";
		List<Department> listDept = session.createQuery(hql).list();
		
		if (listDept.isEmpty()) {
			return null;
		}
		return listDept;
	}
	
}
