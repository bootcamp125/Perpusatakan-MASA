package com.girinuaha.maven.dao;

import java.util.List;

import com.girinuaha.maven.model.Employee;

public interface EmployeeDao {
	
	public void save(Employee employee);
	
	/*public List<Employee> getEmployeeById(int id);*/
	
	public Employee getEmployeeById(int id);
	
	public List<Employee> getAllEmployee();

	public void update(Employee employee);

	public void delete(int id);
}
