package com.girinuaha.maven.controller;

import org.springframework.stereotype.Component;

@Component
public class Address {
	
	private String name;
	private String postalCode;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	
	public String getPostalCode() {
		return postalCode;
	}
}
