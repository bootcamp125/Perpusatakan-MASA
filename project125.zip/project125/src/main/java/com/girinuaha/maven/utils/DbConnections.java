package com.girinuaha.maven.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DbConnections {
	
	private static Connection connection;
	
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			if (connection == null) {
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/db125", "root", "");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public static PreparedStatement getPreparedStatement(Connection connection, String sql) {
		PreparedStatement prepareStatement = null;
		try {
			prepareStatement = connection.prepareStatement(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prepareStatement;
	}
}
