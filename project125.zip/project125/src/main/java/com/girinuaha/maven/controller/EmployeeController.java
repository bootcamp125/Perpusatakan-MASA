package com.girinuaha.maven.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.girinuaha.maven.model.Employee;
import com.girinuaha.maven.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(method=RequestMethod.GET)
	public String index(Model model) {
		List<Employee> employees = employeeService.getAllEmployee();
		model.addAttribute("employees", employees);
		return "employee";
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String saveData(@ModelAttribute Employee employee) {
		employeeService.save(employee);
		return "redirect:/employee";
	}
	
	@RequestMapping(value="/save2", method=RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public void saveData2(@RequestBody Employee employee) {
		employeeService.save(employee);
	}
	
	@RequestMapping(value="/empid/{id}")
	@ResponseBody
	public Employee getEmployeeById(@PathVariable int id) {
		/*List<Employee> emp = employeeService.getEmployeeById(id);
		return emp;*/
		Employee result = employeeService.getEmployeeByID(id);
		return result;
	}
	
	@RequestMapping(value="/update", method=RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	public void updateData(@RequestBody Employee employee) {
		employeeService.update(employee);
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public void deleteData(@PathVariable int id) {
		employeeService.delete(id);
	}
	
	@RequestMapping(value="/allemp", method=RequestMethod.GET)
	@ResponseBody
	public List<Employee> getAllEmployees(){
		List<Employee> employees = employeeService.getAllEmployee();
		
		return employees;
	}
}
